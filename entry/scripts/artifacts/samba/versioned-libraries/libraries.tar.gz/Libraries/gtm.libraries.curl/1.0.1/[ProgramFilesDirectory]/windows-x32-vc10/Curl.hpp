/**
 * @file     include/curl/Curl.hpp
 * @author   JR Lewis
 * @date     02/21/2019
 */


#pragma once

#include <curl/curl.h>
#include <curl/easy.h>

// boost dependencies
#include <boost/filesystem.hpp>

// std dependencies
#include <algorithm>
#include <cstring>
#include <iterator>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#include <regex>

// system dependencies
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>

namespace
{

/**
 * @devicecomm
 */
static const char* __svninfo__ = "";


/**
 * @devicecomm
 */
static const char* __documentation__ = "https://redmine.gentex.com";


/**
 * @devicecomm
 */
static const char* __symbolicname__ = "gtm.libraries.curl";

}


/* NOTE: if you want this example to work on Windows with libcurl as a
   DLL, you MUST also provide a read callback with CURLOPT_READFUNCTION.
   Failing to do so will give you a crash since a DLL may not use the
   variable's memory when passed in to it from an app like this. */ 
static size_t read_callback(void *ptr, size_t size, size_t nmemb, void *stream)
{
  curl_off_t nread;
  /* in real-world cases, this would probably get this data differently
     as this fread() stuff is exactly what the library already would do
     by default internally */ 
  size_t retcode = fread(ptr, size, nmemb, (FILE*) stream);
 
  nread = (curl_off_t)retcode;
 
//  fprintf(stderr, "*** We read %" CURL_FORMAT_CURL_OFF_T
 //         " bytes from file\n", nread);
  return retcode;
}


class CurlSingleton 
{
public:

	static CurlSingleton* Instance()
	{
		static std::unique_ptr<CurlSingleton> instance;
		if (instance == nullptr)
		{
			instance.reset(new CurlSingleton());
		}
		return instance.get();
	}

	
	void GlobalInitialize()
	{
		if (false == m_globalInitialized)
		{
			curl_global_init(CURL_GLOBAL_ALL);
			m_globalInitialized = true;
		}
	}


	void GlobalDestroy()
	{
		if (true == m_globalInitialized)
		{
			curl_global_cleanup();
			m_globalInitialized = false;
		}
	}


	std::pair<int, CURL*> EasyInit()
	{
		m_curl = curl_easy_init();	
		return std::make_pair( 0, m_curl );
	}


	void EasyCleanup( int  )
	{
		curl_easy_cleanup(m_curl);
		m_curl = nullptr;
	}

private:
	CurlSingleton() 
	: m_globalInitialized(false)
	, m_curl(nullptr)
	{ 
	}

	CurlSingleton(CurlSingleton const&) { }

	//! Has the curl system been globally initializeD?
	bool m_globalInitialized;

	CURL* m_curl;
};


inline
/**
 * Obtain the specific version of curl being used.
 * @devicecomm
 * @return version The curl version string.
 */
std::string Version()
{
	std::stringstream ss;
	ss << curl_version();
	return ss.str();
}


inline
/**
 * Initialize the curl subsystem globally. This is required to 
 * work with Curl libraries. 
 * @devicecomm
 */
void Initialize()
{
	CurlSingleton::Instance()->GlobalInitialize();
}


inline
/**
 * Destroy the global curl initializations.
 * @devicecomm
 */
void Destroy()
{
	CurlSingleton::Instance()->GlobalDestroy();
}


template <typename T1, typename T2>
std::string Concat( T1 t1, T2 t2 )
{
	std::stringstream ss;
	ss << t1 << t2;
	return ss.str();
}


inline
/**
 * Upload a file via ftp.
 *
 * @devicecomm
 *
 * @param localFilePath The local file name of what is going to be uploaded
 * @param remotePath The remote url you are uploading to (without filename)
 * @param log A bunch of log messages that occurred during the ftp upload.
 */
void FtpUpload( std::string localFilePath, std::string remotePath, std::string& log )
{
	std::stringstream logMessage;

	CURLcode res;
	FILE *hd_src;
	struct stat file_info;
	curl_off_t fsize = 0;
 
	struct curl_slist *headerlist = nullptr;

	/* get the file size of the local file */ 
	if(stat(localFilePath.c_str(), &file_info)) 
	{
		std::stringstream ss;
		ss << "Couldn't open '" << localFilePath << "' : " << strerror(errno);
		throw std::runtime_error(ss.str());
	}

	fsize = (curl_off_t)file_info.st_size;

	logMessage << "Local file size: " << fsize << " bytes.\n";

	/* get a FILE * of the same file */ 
	hd_src = fopen(localFilePath.c_str(), "rb");

	/* In windows, this will init the winsock stuff */ 
	Initialize();

	/* get a curl handle */ 
	auto curlPair = CurlSingleton::Instance()->EasyInit();
	auto curl = curlPair.second;

	if(curl) 
	{
		/* we want to use our own read function */ 
		curl_easy_setopt(curl, CURLOPT_READFUNCTION, read_callback);

		/* enable uploading */ 
		curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);

		/* specify target */ 
		curl_easy_setopt(curl, CURLOPT_URL, remotePath.c_str());

		/* pass in that last of FTP commands to run after the transfer */ 
		curl_easy_setopt(curl, CURLOPT_POSTQUOTE, headerlist);

		/* now specify which file to upload */ 
		curl_easy_setopt(curl, CURLOPT_READDATA, hd_src);

		/* Set the size of the file to upload (optional).  If you give a *_LARGE
		option you MUST make sure that the type of the passed-in argument is a
		curl_off_t. If you use CURLOPT_INFILESIZE (without _LARGE) you must
		make sure that to pass in a type 'long' argument. */ 
		curl_easy_setopt(curl, CURLOPT_INFILESIZE_LARGE,
			(curl_off_t)fsize);

		/* Now run off and do what you've been told! */ 
		res = curl_easy_perform(curl);
		/* Check for errors */ 
		if(res != CURLE_OK)
		{
			std::stringstream ss;
			ss << "curl_easy_perform() failed: " << curl_easy_strerror(res);
			throw std::runtime_error(ss.str());
		}

		/* clean up the FTP commands list */ 
		curl_slist_free_all(headerlist);

		/* always cleanup */ 
		CurlSingleton::Instance()->EasyCleanup( curlPair.first );
	}	
	else
	{
		std::stringstream ss;
		ss << "Did not get a valid Curl object.";
		throw std::runtime_error(ss.str());
	}

	log = logMessage.str();
}


inline std::string ConstructRemoteFilePath( std::string server, std::string remotePath)
{
	return server + remotePath;
}


struct FtpFile 
{
	const char* filename;
	FILE* stream;
};


static size_t my_fwrite(void* buffer, size_t size, size_t nmemb, void* stream)
{
	struct FtpFile* out = (struct FtpFile*) stream;
	if (nullptr == out->stream)
	{
		out->stream = fopen(out->filename, "wb");
		if (out->stream == nullptr)
		{
			return -1;
		}
	}
	return fwrite(buffer, size, nmemb, out->stream);
}


inline std::vector<std::string> Split(std::string remotePath)
{
	if (remotePath.empty() == false && (remotePath[0] == '/' || remotePath[0] == '\\'))
	{
		remotePath = remotePath.substr(1);
	}

	std::vector<std::string> out;	
	size_t lastIndex = 0;
	for(size_t i=1; i<remotePath.size(); ++i)
	{
		if (remotePath[i] == '/' || remotePath[i] == '\\')
		{
			out.push_back(remotePath.substr(lastIndex, i - lastIndex));
			lastIndex = i+1;
			++i;
			continue;
		}
	}

	if (lastIndex < remotePath.size())
	{
		out.push_back(remotePath.substr(lastIndex));
	}

	return out;
}


inline std::string ConstructLocalFilePath( std::string remotePath, std::string destDir)
{
	std::vector<std::string> dirs = Split(remotePath);
	auto end = dirs.end();
	if (end != dirs.begin())
	{
		--end;
	}

	std::string currentPath = destDir;
	std::for_each( dirs.begin(), end, [&currentPath](std::string nextDir)
	{
		currentPath += "/";
		currentPath += nextDir;
		boost::filesystem::create_directory(currentPath);
	});

	return (currentPath + "/" + dirs.back());
}


inline
/**
 * Download a file via ftp.
 *
 * @devicecomm
 *
 * @param server The server where the ftp site is located
 * @param remotePath The path on the server where the file is
 * @param destDir The destination directory.
 * @param log A bunch of log messages that occurred during the ftp download
 */
void FtpDownload( std::string server, std::string remotePath, std::string destDir, std::string& log )
{
	std::stringstream logMessage;

	CURLcode res;
	FILE *hd_src;
	curl_off_t fsize = 0;

	std::string localFilePath = ConstructLocalFilePath( remotePath, destDir );

	// Never seen this syntax before.
	struct FtpFile ftpfile = 
	{
		localFilePath.c_str(), nullptr
	};
		

	std::string remoteFilePath = ConstructRemoteFilePath( server, remotePath );
 
	struct curl_slist *headerlist = nullptr;

	/* In windows, this will init the winsock stuff */ 
	Initialize();

	/* get a curl handle */ 
	auto curlPair = CurlSingleton::Instance()->EasyInit();
	auto curl = curlPair.second;

	if(curl) 
	{
		curl_easy_setopt(curl, CURLOPT_URL, remoteFilePath.c_str() );
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_fwrite );
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ftpfile);

		/* Now run off and do what you've been told! */ 
		res = curl_easy_perform(curl);
		/* Check for errors */ 
		if(res != CURLE_OK)
		{
			std::stringstream ss;
			ss << "curl_easy_perform() failed: " << curl_easy_strerror(res);
			throw std::runtime_error(ss.str());
		}

		/* clean up the FTP commands list */ 
		curl_slist_free_all(headerlist);

		/* always cleanup */ 
		CurlSingleton::Instance()->EasyCleanup( curlPair.first );

		if (ftpfile.stream)
		{
			fclose(ftpfile.stream);
		}
	}	
	else
	{
		std::stringstream ss;
		ss << "Did not get a valid Curl object.";
		throw std::runtime_error(ss.str());
	}

	log = logMessage.str();
}
