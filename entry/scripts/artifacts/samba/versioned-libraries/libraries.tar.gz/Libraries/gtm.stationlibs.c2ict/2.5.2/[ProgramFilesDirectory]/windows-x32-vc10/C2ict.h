/**
	@file
	@author Chris Cuddohy
	@date 5-11-2012
	@brief Library for ICT station of Combo II
*/

#ifndef COMBO2ICT_H 
#define COMBO2ICT_H

//disables warning C4251: 'C2ict::m_imp' : class 'boost::shared_ptr<T>' needs to have dll-interface to be used by clients of class 'C2ict'
#pragma warning(disable:4251)

#include <boost/smart_ptr/shared_ptr.hpp>
#include "C2ictDLL.h"
#include <string>

/**
 * @devicecomm
 * DO NOT EDIT - This property value will be updated automatically every time this file is committed to Subversion.
 * @NOTE The SVN keyword "header" property is required to be added to this file in order for this to work.
 */
static const char* __svninfo__ = "$Header: http://vcs.gentex.com/svn/libraries/gentex/cpp/C2stations/C2ICTstation/trunk/include/c2ICT/C2ict.h 50038 2019-05-07 15:37:42Z scott.hanson $";

/**
 * @devicecomm 
 */
static const char* __documentation__ = "https://redmine.gentex.com/projects/combo2-instrumentation/wiki/_ICT_Station";

/**
 * @devicecomm 
 */
static const char* __symbolicname__ = "gtm.stationlibs.c2ict";

/**
 * Possible Measure Amplifier resistor value configurations 
 * @devicecomm
 */
typedef enum
{
	MA_UNKNOWN = 0,
	MA_10 = 10,
	MA_100 = 100,
	MA_1K = 1000,
	MA_10K = 10000,
	MA_100K = 100000,
	MA_1M = 1000000,
	MA_10M = 10000000
}MeasureAmpResistorVal;

/** 
 * Defines configuration of the guard amplifiers. They can be configured for guard point, used as force amplifier to
 * force voltage from a separate, dedicated analog output or the output can be disconnected from the measure bus. 
 * @devicecomm
 */
typedef enum 
{
	GUARDPOINT_MODE,
	SOURCEAMPLIFIER_MODE,
	GUARDAMP_DISCONNECT
}GuardAmpMode;             

/**
 * @devicecomm
 * Possible Force Current Amplifier resistor value configurations  
*/
typedef enum
{
	FI_RESNOTUSED = -1,
	FI_UNKNOWN = 0,
	FI_100 = 100,
	FI_1K = 1000,
	FI_10K = 10000,
	FI_100K = 100000,
	FI_1M = 1000000
}ForceCurrentResistorVal;

/**
 * Possible force modes  
 * @devicecomm
*/
typedef enum
{
	FORCE_CURRENT_MODE,
	FORCE_VOLTAGE_MODE
}ForceCurForceVoltMode;

/**
 * Possible measurement modes  
 * @devicecomm
*/
typedef enum
{
	FOURWIRE_MODE,
	TWOWIRE_MODE
}FourWireTwoWireMode;


/**
 * Capacitance measurement modes  
 * @devicecomm
*/
typedef enum
{
	SERIESMEASUREMENT,
	PARALLELMEASUREMENT
}CapacitanceTestMode;

class C2ictIMP;

/**
 * Combo2 in-circuit test station library with DCIGen bindings.
 * @devicecomm
 */
class __declspec(dllexport) C2ict
{
public:

	C2ict();
	~C2ict();

	/** 
	* Reads: the configFile, to configure generic tester specifics defined there and the ProductFile to configure the tester and
	* software for product specific details. Also presets the state of the instruments.
	*
	* @devicecomm
	* @param configFile The config file to configure generic tester specifics
	* @param productFile to configure the tester and software for product specific details.
	*/
	void Initialize( const std::string &configFile, const std::string &productFile );

	/** 
	* Initializes the ICT interface using default Combo 2 config file names and locations
	* TesterConfig: C:/Tester/Combo2_Station2/Combo2_Station2.cfg
	* ProductConfig: C:/Tester/Combo2_Station2/Combo2_Station2_Product.cfg
	* @devicecomm
	*/
	void Initialize_Combo2_Station2();

	/** 
	* Initializes the ICT interface using default Monorail ICT1 config file names and locations
	* TesterConfig: C:/Tester/MR_ICT1/ICTStation.cfg
	* ProductConfig: C:/Tester/MR_ICT1/ICT_ProductConfig.cfg
	* @devicecomm
	*/
	void Initialize_Monorail_ICT1();

	/** 
	* Initializes the ICT interface using default Monorail ICT2 config file names and locations
	* TesterConfig: C:/Tester/MR_ICT2/ICTStation.cfg
	* ProductConfig: C:/Tester/MR_ICT2/ICT_ProductConfig.cfg
	* @devicecomm
	*/
	void Initialize_Monorail_ICT2();

	/** 
	* Is The interface Initialized
	* @devicecomm
	* @return out Initialized Status
	*/
	bool IsInitialized();
	
	/**
	* Clears all the captured data, disconnects the switch matrix and sets the analog output to zero. Should be called at
	* the end of each DUT test cycle.
	*
	* @devicecomm
	*/
	void CleanUp();
		
	/** 
	* Writes previously captured data, that is stored internally, referenced to TagID to a file. Also writes the sample rate.
	* @devicecomm
	* @param tagID the string id of the waveform captured using the same string id
	* @param filePath name and path of the file to write
	* @param throwIfEmpty if true and TagID is not found will throw
	*/
	void WriteCapturedWaveformToFile( const std::string &tagID, const std::string &filePath, bool throwIfEmpty );


	/** 
	* Configure the interface to force voltage mode with options to set the Guard circuits G0 & G1 to guard 
	* point or force voltage mode or to disconnect them. The function also sets the Measure Amp resistor
	* value. If setting the Guard modes to SOURCEAMPLIFIER_MODE the Analog output amps will set to zero if
	* not in SOURCEAMPLIFIER_MODE. If already in SOURCEAMPLIFIER_MODE, the analog output amps are not
	* changed. If was not previously in FORCE_VOLTAGE_MODE, the source amp analog output is set to zero.
	* Otherwise it is not changed.
	*
	* @devicecomm 
	* @param g0guardMode GuardAmpMode Mode for G0
	* @param g1guardMode GuardAmpMode Mode for G1
	* @param maResistor Measure Amp resistor
	*/
	void ConfigFV_setup( GuardAmpMode g0guardMode, GuardAmpMode g1guardMode, MeasureAmpResistorVal maResistor  );

	/** 
	* Configure the measure system to four wire mode and set the value of the Measure Amp resistor. In four wire
	* mode the guard amplifiers cannot be used.
	*
	* @devicecomm 
	* @param maResistor Measure Amp resistor
	*/
	void ConfigFV4W_setup( MeasureAmpResistorVal maResistor );

	/** 
	* Configure the measure system to force current, set the guard amplifiers to the desired mode and set the Measure Amp 
	* resistor value. This function is preferred  when forcing currents up to 10ma and the resulting voltage is less than 10v.
	* When higher currents or voltages are necessary use ConfigExtRangeFI_setup(). This function has better resolution, allows
	* guard point and the ability to measure the force current.
	* 
	* @devicecomm 
	*
	* @param g0guardMode GuardAmpMode for G0
	* @param g1guardMode GuardAmpMode for G1
	* @param maResistor Measure Amp resistor
	*/
	void ConfigFI_setup( GuardAmpMode g0guardMode, GuardAmpMode g1guardMode, MeasureAmpResistorVal maResistor );


	/** 
	* Configure the measure system to force current in the extended range force current mode. Voltages up to 40vdc with current up
	* to 50ma are achievable. Guard point is not possible and the ability to measure the forcing current is not possible with this 
	* function. For those features and if forcing lower currents and voltages up to 10v, use ConfigFI_setup(). ConfigFI_setup() 
	* also has much better resolution. 
	* 
	* @devicecomm 
	*
	* @param g0guardMode GuardAmpMode for G0 either force mode or disconnected
	* @param g1guardMode GuardAmpMode for G1 either force mode or disconnected
	*/
	void ConfigExtRangeFI_setup( GuardAmpMode g0guardMode, GuardAmpMode g1guardMode );

	/** 
	* Configure the measure system to force current and configure four wire measure. 
	*
	* @devicecomm 
	*
	* @param maResistor Measure Amp resistor
	*/
	void ConfigFI_4Wsetup( MeasureAmpResistorVal maResistor );


	/** 
	* Configure the measure system to force current using the extended range system and configure four wire measure. 
	*
	* @devicecomm 
	*/
	void ConfigExtendedRangeFI_4Wsetup();



	/** 
	* Terminates all active connections on the switches
	*
	* @devicecomm 
	*/
	void DisconnectSwMatrix();
			
	/** 
	* Set the DC voltage output from the Source Amp when configured for force voltage. If the voltage is already set to a 
	* different voltage, the function will set the output to zero, set the switch and then set the DAC.
	* 
	* @devicecomm 
	* @param voltage DC Voltage
	* @param sourceAmpNode DUT node to connect to Source Amp, Row3
	* @param measureAmpNode DUT node to connect to Measure Amp, Row2
	
	*/
	void SetDCStimulus( double voltage, const std::string &sourceAmpNode, const std::string &measureAmpNode );

	/** 
	* Set the AC sine voltage output from the Source Amp configured for force voltage. If there is a DC voltage being sourced;
	* a sine wave with a higher amplitude; different offset or a different frequency, the output amp first set the output to
	* zero volts then sets the switch and sets the sine wave.
	*
	* @devicecomm 
	* @param vpeak_peak Sine wave peak to peak amplitude
	* @param frequency Sine wave frequency
	* @param dCoffset DC offset of sine wave	
	* @param sourceAmpNode DUT node to connect to Source Amp, Row3
	* @param measureAmpNode DUT node to connect to Measure Amp, Row2
	*/
	void SetSineStimulus( double vpeak_peak, double frequency, double dCoffset, const std::string &sourceAmpNode, 
		const std::string &measureAmpNode );

	
	/** 
	* Set the Force Current Amplitude. The polarity of the Current argument will correspond to the polarity of the current at the 
	* source drive output referenced to the Measure Amp. When in Extended Range Zener mode, the current argument must be positive.
	* The function first disconnects the switch matrix then sets the current and clamp parameters and then sets the switch matrix. 
	* The voltage developed at the output of the force circuit is clamped to the ClampVoltage argument but *** SOME OVERSHOOT SHOULD 
	* BE EXPECTED *** if the DUT does not clamp the voltage; more details below. The clamp feature may be important to protect surrounding
	* circuitry from over voltage if a fault occurs. For example: when checking a voltage drop across a semiconductor junction by
	* forcing current, if the semiconductor is miss-placed, the resulting voltage would approach  the rail of the force amplifier. 
	* Surrounding circuitry could be damaged or stressed if sensitive to the resulting rail voltage. Clamping the voltage offers
	* a method to protect for over-voltage stress. The minimum clamping voltage is approximately +/- .5 Vdc. If the DUT does not
	* clamp the voltage, the voltage will overshoot, The overshoot depends on the specific circumstances of the test and the DUT but
	* the peak could be in the neighborhood of two volts on the normal range and five volts in the extended range mode. The waveform 
	* shape of the overshoot will likely be tringular and have a total duration in the neighborhood of 5us. 
	*
	* @devicecomm 
	* @param current DC force current
	* @param clampVoltage Max allowed voltage from attempting to force current.
	* @param sourceAmpNode DUT node to connect to Source Amp, Row3
	* @param measureAmpNode DUT node to connect to Measure Amp, Row2
	*/
	void SetForceCurrentStimulus( double current, double clampVoltage, const std::string &sourceAmpNode, 
		const std::string &measureAmpNode );

	/** 
	*Set the G0 force amp DC voltage. If the voltage is already set to something different the switch is disconnected, the
	* output is set and then the switch is set. If the node argument is empty, the switch matrix for the row is disconnected.
	* This function should not be called following a call to SetSineStimulus() unless preceded with SetDCStimulus(). The function
	* will throw if not.
	*
	* @devicecomm
	* @param voltage Guard 0 Voltage when in the source amp mode
	* @param g0node DUT node to connect to G0 Amp, Row0
	*/
	void SetG0DC( double voltage, const std::string &g0node );

	/** 
	* Set the G1 force amp DC voltage.  If the voltage is already set to something different the switch is disconnected, the
	* output is set and then the switch is set. If the node argument is empty, the switch matrix for the row is disconnected.
	* This function should not be called following a call to SetSineStimulus() unless preceded with SetDCStimulus(). The function
	* will throw if not.
	*
	* @devicecomm 
	* @param voltage Guard 1 voltage
	* @param g1node DUT node to connect to G1 Amp, Row1
	*/
	void SetG1DC( double voltage, const std::string &g1node  );

	/**
	* Set the Guard Point for row 0 (guard point amp0). An empty string disconnects Row0 switch matrix.
	* @devicecomm
	* 
	* @param g0node DUT node to connect to guard point row 0 Amp
	*/
	void SetG0guardPoint( const std::string &g0node );


	/**
	* Set the four wire pair row 0 the DUT node. An empty string disconnects Row0 switch matrix.
	* @devicecomm
	* 
	* @param g0node DUT node to connect to four wire row 0 input
	*/
	void SetFourWireRow0( const std::string &g0node );

	/**
	* Set the four wire pair row 1 the DUT node. An empty string disconnects Row1 switch matrix.
	* @devicecomm
	* 
	* @param g1node DUT node to connect to four wire row 1 input
	*/
	void SetFourWireRow1( const std::string &g1node );


	/**
	* Set the Guard Point for row 1 (guard point amp0). An empty string disconnects Row1 switch matrix.
	* @devicecomm
	* 
	* @param g1node DUT node to connect to guard point row 1 Amp
	*/
	void SetG1guardPoint( const std::string &g1node );

	/** 
	* Sets the analog input ranges for the signal conditioning amps on the Measure Source Pair and across the MA resistor; 
	* makes the DC voltage measurements and calculates the DC resistance. 
	*
	* @devicecomm 
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrangeMAcur Analog Input range (in amps) for the Measure Amp Analog Input amp 
	* @param tag Name to assign to measurement, used for logging
	* @return out DC Resistance
	*/
	double MeasureDCRes( double aIrangeMSpair, double aIrangeMAcur, const std::string &tag );


	/** 
	* Sets the analog input ranges for the signal conditioning amps on the 4 wire pair and across the MA resistor; 
	* makes the DC voltage measurements and calculates the DC resistance. 
	*
	* @devicecomm 
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrangeMAcur Analog Input range (in amps) at the Force Current Amp analog input amp 
	* @param tag Name to assign to measurement, used for logging
	* @return out DC Resistance
	*/
	double MeasureDCRes4W( double aIrange4Wpair, double aIrangeMAcur, const std::string &tag );


	/** 
	* Sets the analog input ranges for the signal conditioning amps on the Measure Source Pair and across the MA resistor; 
	* determines the sample rate and phase measurement hysteresis; does a waveform read and calculates the Capacitance using the 
	* series calculation. 
	*
	* @devicecomm 
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrangeMAcur Analog Input range (in p-p amps) for the Measure Amp Analog Input amp 
	* @param tag Name to assign to measurement, used for logging
	* @return out Capacitance using series calculation
	*/
	double MeasureCapacitanceSeries( double aIrangeMSpair, double aIrangeMAcur, const std::string &tag );
	
	/**
	* Sets the analog input ranges for the signal conditioning amps on the Measure Source Pair and across the MA resistor; 
	* determines the sample rate and phase measurement hysteresis; does a waveform read and calculates the Capacitance using the 
	* parallel calculation. 
	* @devicecomm 
	*
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrangeMAcur Analog Input range (in p-p amps) for the Measure Amp Analog Input Amp
	* @param tag Name to assign to measurement, used for logging
	* @return out Capacitance using parallel calculation
	*/
	double MeasureCapacitanceParallel( double aIrangeMSpair, double aIrangeMAcur, const std::string &tag );

		
	/** 
	* Sets the analog input range for the signal conditioning amps on the MS pair, the force current resistor and the Measure Amp 
	* resistor. It returns the voltage measured across the MS pair, the current from the Force Current Amp and the current from the 
	* Measure Amp. The polarity of the current measurements from the Force Current Amp and the Measure Amp current represent the 
	* polarity at the source drive output referenced to the Measure Amp. 
	*
	* @devicecomm 
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrangeFIcur Analog Input range (in amps) the Force Current Analog input Amp
	* @param aIrangeMAcur Analog Input range (in amps) of the Measure Amp 
	* @param tag Name to assign to measurement, used for logging
	* @param mSv Voltage at Measure Source Pair
	* @param fI current from Force Current Amp
	* @param mAcur current at the Measure Amp
	*/
	void MeasureMSv_Fcur_MAcur( double aIrangeMSpair, double aIrangeFIcur, double aIrangeMAcur, double &mSv, double &fI, double &mAcur, const std::string &tag );

	/** 
	* Sets the analog input range for the signal conditioning amps on the MS pair and the Measure Amp resistor. It returns the
	* voltage measured across the MS pair and the current from the Measure Amp. 
	*
	* @devicecomm
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrangeMAcur Analog Input range (in amps) for the Measure Amp analog input amp 
	* @param tag Name to assign to measurement, used for logging
	* @param mSv Voltage at Measure Source Pair
	* @param mAcur current at the Measure Amp
	*/
	void MeasureMSv_MAcur( double aIrangeMSpair, double aIrangeMAcur, double &mSv, double &mAcur, const std::string &tag );


	/** 
	* Sets the analog input range for the signal conditioning amps on the MS pair and the Measure Amp resistor. It returns the
	* RMS voltage measured across the MS pair and the RMS current from the Measure Amp and the number of samples per cycle. 
	*
	* @devicecomm
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrangeMAcur Analog Input range (in amps) for the Measure Amp analog input amp 
	* @param tag Name to assign to measurement, used for logging
	* @param mSv Voltage at Measure Source Pair
	* @param mAcur current at the Measure Amp
	* @param tag Name to assign to measurement, used for logging
	*/
	void MeasureRMS_MSv_MAcur( double aIrangeMSpair, double aIrangeMAcur, double &mSv, double &mAcur, const std::string &tag );


	/** 
	* Sets the analog input range for the signal conditioning amps on the 4 wire pair and the Measure Amp resistor. It returns the
	* voltage measured across the 4wire pair and the current from the Measure Amp. When the voltage across the 4-wire pair is
	* greater than +-10 volts set the arg fourW_highGain to false.
	*
	* @devicecomm 
	* @param aIrange4Wpair Analog Input voltage range at the 4wire pair 
	* @param aIrangeMAcur Analog Input range (in amps) for the Measure Amp Analog Input Amp 
	* @param fourWireV Voltage at 4Wire Pair
	* @param mAcur current at the Measure Amp
	* @param fourW_highGain when true the analog input used is unit gain with max +-10v
	* @param tag Name to assign to measurement, used for logging
	*/
	void Measure4Wv_MAcur( double AIrange4Wpair, double aIrangeMAcur, double &fourWireV, double &mAcur, bool fourW_highGain, const std::string &tag );

	/** 
	* Sets the analog input range for the signal conditioning amps on the 4 wire pair, the Force Current Amp resistor and 
	* the Measure Amp resistor. It returns the voltage measured across the 4wire pair, the current from the Force Current Amp 
	* and the current from the Measure Amp. When the voltage across the 4-wire pair is greater than +-10 volts set the arg 
	* fourW_highGain to false.
	*
	* @devicecomm 
	* @param aIrange4Wpair Analog Input voltage range at the 4wire pair 
	* @param aIrangeFIcur Analog Input range (in amps) for the force current amp
	* @param aIrangeMAcur Analog Input range (in amps) for the Measure Amp Analog Input Amp 
	* @param fourWireV Voltage at 4Wire Pair
	* @param fI Force current
	* @param mAcur Measure Amp current
	* @param fourW_highGain when true the analog input used is unit gain with max +-10v
	* @param tag Name to assign to measurement, used for logging
	*/
	void Measure4Wv_Fcur_MAcur( double aIrange4Wpair, double aIrangeFIcur, double aIrangeMAcur, double &fourWireV, 
		double &fI, double &mAcur, bool fourW_highGain, const std::string &tag );
	
	/** 
	* Sets the analog input range for the signal conditioning amps on the G1 res, the Measure Amp resistor, the Measure 
	* Source pair, the force current res and the 4wire pair. It returns the voltage measured across the MS pair, the voltage 
	* across the 4wirePair, the current from the guard Point amp, the current from the Measure Amp and the current from the 
	* Force Current Amp, When the voltage across the 4-wire pair is greater than +-2.4 volts use this function if not use 
	* MeasureG1curMAcurFIcurMSvGpairVhg.
	*
	* @devicecomm 
	* @param aIrangeG1cur Analog Input range (in amps) for the Guard1 amp 
	* @param aIrangeMAcur Analog Input range (in amps) for Measure Amp 
	* @param aIrangeFIcur Analog Input range (in amps) for the Force Current Analog Input Amp 
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrange4Wpair Analog Input voltage range at the 4wire pair
	* @param g1cur Current from the G1 Amp
	* @param mAcur Current from the Measure Amp
	* @param fIcur current at the Force Current Amp
	* @param mSv Measure source voltage
	* @param fourWireV Voltage at 4Wire Pair
	* @param tag Name to assign to measurement, used for logging
	*/
	void MeasureG1curMAcurFIcurMSvGpairV( double aIrangeG1cur, double aIrangeMAcur,  double aIrangeFIcur, double aIrangeMSpair, 
		double aIrange4Wpair, double &g1cur, double &mAcur, double &fIcur, double &mSv, double &fourWireV, const std::string &tag );


	/** 
	* Sets the analog input range for the signal conditioning amps on the G1 res, the Measure Amp resistor, the Measure 
	* Source pair, the force current res and the 4wire pair. It returns the voltage measured across the MS pair, the 4wirePair,
	* the current from the guard Point amp and the current from the Measure Amp and the current from the Force Current Amp, When 
	* the voltage across the 4-wire pair is less than +-2.4 volts use this function if not use MeasureG1curMAcurFIcurMSvGpairV.
	*
	* @devicecomm 
	* @param aIrangeG1cur Analog Input range (in amps) for the Guard1 analog input amp 
	* @param aIrangeMAcur Analog Input range (in amps) for the Measure Amp analog input amp 
	* @param aIrangeFIcur Analog Input range (in amps) for the Force Current Amp analog input amp 
	* @param aIrangeMSpair Analog Input voltage range at the Measure Source Pair
	* @param aIrange4Wpair Analog Input voltage range at the 4wire pair
	* @param g1cur Current from the G1 Amp
	* @param mAcur Current from the Measure Amp
	* @param fIcur current at the Force Current Amp
	* @param mSv Measure source voltage
	* @param fourWireV Voltage at 4Wire Pair
	* @param tag Name to assign to measurement, used for logging
	*/
	void MeasureG1curMAcurFIcurMSvGpairVhg( double aIrangeG1cur, double aIrangeMAcur,  double aIrangeFIcur, double aIrangeMSpair, 
		double aIrange4Wpair, double &g1cur, double &mAcur, double &fIcur, double &mSv, double &fourWireV, const std::string &tag );

	/**
	* Measure the voltage across the MS pair when in the Extended Range Zener mode. 
	* @devicecomm 
	* @param range the range of the analog input amp. Maximum is 40
	* @param tag Name to assign to measurement, used for logging
	* @return out DC Voltage
	*/
	double MeasureExRngMSv( double range, const std::string &tag ); 

	/**
	* Measure the voltage across the 4 wire pair using the high gain (+-10v max) analog input amp or the low gain (+-40v max)
	* analog input amp.
	* @devicecomm 
	* @param range the range of the analog input amp. Maximum is 10 for high gain, 40 for low gain
	* @param fourW_highGain true for high gain analog input amp
	* @param tag Name to assign to measurement, used for logging
	* @return out DC Voltage
	*/
	double Measure4wPairV( double range, bool fourW_highGain, const std::string &tag );  



	/**
	* Measure the voltage across the G0 resistor (G0 current), the MA resistor (MA cur) and the four wire pair.  
	* @devicecomm
	* @param aiRangeG0cur the analog input range of the current through the G0 source amp
	* @param aiRangeMAcur the analog input range of the current through the measure amp
	* @param aiRange4Wpair the analog input range of the voltage across the four wire pair (+-40v max )
	* @param g0cur the current through the g0 amp
	* @param maCur the current through the measure amp
	* @param fourWireV the voltage across the four wire pair (low gain)
	* @param tag Name to assign to measurement, used for logging
	*/
	void MeasureG0curMAcur4WpairV( double aiRangeG0cur, double aiRangeMAcur, double aiRange4Wpair, double &g0cur, double &maCur, 
		double &fourWireV, const std::string &tag );


	/**
	* Measure the voltage across the G1 resistor (G1 current), the MA resistor (MA cur) and the four wire pair.  
	* @devicecomm
	* @param aiRangeG1cur the analog input range of the current through the G1 source amp
	* @param aiRangeMAcur the analog input range of the current through the measure amp
	* @param aiRange4Wpair the analog input range of the voltage across the four wire pair (+-40v max )
	* @param g1cur the current through the g0 amp
	* @param maCur the current through the measure amp
	* @param fourWireV the voltage across the four wire pair (low gain)
	* @param tag Name to assign to measurement, used for logging
	*/
	void MeasureG1curMAcur4WpairV( double aiRangeG1cur, double aiRangeMAcur, double aiRange4Wpair, double &g1cur, double &maCur, 
		double &fourWireV, const std::string &tag );


	/** for testing only */
	const C2ictIMP* getIMP();

	
	/**
	* Tests for shorts between every node. This function requires test groups file, generated in the development process and identified
	* in the product configuration file. If there are any shorts, the argument nodesShorted will not be empty. The function returns the
	* number of measurements made. To speed the process of identifying shorts, the initial measurements are made with various combinations 
	* of nodes grouped together. If a resistance measurement of a particular combination of nodes is below the resistance threshold, a second
	* set of measurements is performed to locate the actual nodes with a resistance below the threshold. The argument lowestResistanceFound
	* is the lowest resistance found either in the initial series of measurements or in the second set of measurements if the initial series
	* encounters a reading below the threshold. 
	* @devicecomm 
	* 
	* @param stimulusVoltage The voltage to be used for making the resistance measurements
	* @param resistanceThreshold The threshold of resistance that indicates a short. Acceptable range is 15 to 1000
	* @param nodesShorted Comma delimited string of the shorted nodes.
	* @param lowestResistanceFound the minimum resistance measured
	* @param boardIndex identifies the board when testing arrays of boards (1 index), A value of zero represents a non-array board
	* @return out number of measurements taken 
	*/
	int ShortsTest( double stimulusVoltage, double resistanceThreshold, std::string &nodesShorted, double &lowestResistanceFound,
		int boardIndex );

	/**
	* Tests for shorts between every node. This function requires test groups file, generated in the development process and identified
	* in the product configuration file. If there are any shorts, the argument nodesShorted will not be empty. The function returns the
	* number of measurements made. To speed the process of identifying shorts, the initial measurements are made with various combinations 
	* of nodes grouped together. If a response current measurement of a particular combination of nodes is above the threshold, a second
	* set of measurements is performed to locate the actual nodes with a response current above the threshold. The argument highestCurrentFound
	* is the highest response current found either in the initial series of measurements or in the second set of measurements if the initial series
	* encounters a reading above the threshold. 
	* @devicecomm 
	* 
	* @param stimulusVoltage The voltage to be used for making the resistance measurements
	* @param currentThreshold The threshold of response currrent that indicates a short. Acceptable range is 100e-6 to 20e-3
	* @param nodesShorted Comma delimited string of the shorted nodes.
	* @param lowestResistanceFound the minimum resistance measured
	* @param boardIndex identifies the board when testing arrays of boards (1 index), A value of zero represents a non-array board
	* @return out number of measurements taken 
	*/
	int ShortsTestResponseCur( double stimulusVoltage, double currentThreshold, std::string &nodesShorted, double &highestCurrentFound,
		int boardIndex );



	/**
	* Sleeps the thread for the duration, in milliseconds.
	* @devicecomm 
	*
	* @param ms_time duration in milliseconds to sleep
	*/
	void Sleep( int ms_time );


	/**
	* Does series of setups and measurements, using loop back and self measure. It uses shorted nodes and open nodes to perform simple self
	* tests of the input and output signals. The function first calls CleanUp() then replaces the node map with one that has the only the 
	* required columns with known assignments. The instructions are then run and evaluated with the results stored in results. CleanUp()
	* is called after the instructions and then the original node map is loaded. The self tests do not test everything and are particularly 
	* lacking in switch matrix testing. For a list of tests and format of the results string, see the document C2_ICT_QuickReference. DO NOT 
	* RUN THIS FUNCTION WITH A DUT CONNECTED TO THE PROBE PLATE. VOLTAGES IN EXCESS OF 35 VOLTS ARE GENERATED ON THE COLUMNS USED FOR THE OPEN
	* TESTS!
	* @devicecomm 
	*
	* @param results a formatted string containing the results of the self tests
	* @param limitFile a file that is used to define the limits for self test evaluation.  
	* @return out true if there are no self test failures. Note that the entries in the limit file determine what measurements are evaluated
	*
	*/
	bool SelfTest( std::string &results, const std::string &limitFile );


	/**
	* Set general purpose (spare) digital lines to the desired state. A state value of two means the
	* digital line is set to the read state, which is a pseudo Hi Z state. It is called pseudo because the
	* line has a built in pull down resistor of approximately 50k ohms, minimum of 20k ohms (PXIe 6363). 
	* The PXIe 6363 maximum output current is +/-24 mA. The input voltage protection is +/- 20 V on up to
	* two pins. only the general purpose digital lines (spare I/O on J12) can be controlled with this 
	* function. These lines have an ID of SpareDig_P0.XX, where XX is from 18 to 25.
	* @devicecomm
	* 
	* @param lineID GP digital line, example SpareDig_P0.XX
	* @param state to set lines, 0 is digital low, 1 is digital high, 2 is read, pseudo hi Z
	*/
	void Set_GPdigital( const std::string &lineID, int stateParameter );

	/**
	* Returns the revision of the station library
	* @devicecomm
	* @return out the GPack revision
	*/
	std::string GetRevision();

	/**
	* Setup Interface to force voltage mode, force the voltage, delay, and measure the resistance.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param forceVoltage Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param MSPairMeasureRange Node A/B Voltage Range
	* @param MACurrentMeasureRange Measurement Amp Current Range
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredResistance in ohms.
	*/
	double ResistorTestAllParameters(const std::string &nodeA, const std::string &nodeB, const std::string &tag , double forceVoltage = 0.15, MeasureAmpResistorVal maResistorValue = MA_100K,
		double MSPairMeasureRange = 0.05, double MACurrentMeasureRange = 0.000005, int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false);

	/**
	* Setup Interface to force voltage mode, force the voltage, delay, and measure the resistance.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param forceVoltage Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredResistance in ohms.
	*/
	double ResistorTest(const std::string &nodeA, const std::string &nodeB, const std::string &tag , double forceVoltage = 0.15, MeasureAmpResistorVal maResistorValue = MA_100K, int delayMS = 0, 
		const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false);

	/**
	* Setup Interface to force voltage mode, force the voltage, delay, and measure the resistance.
	* @devicecomm 
	*
	* @param resistorValue Expected Resistance value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param forceVoltage Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredResistance in ohms.
	*/
	double ResistorTestValue(double resistorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag , double forceVoltage = 0.15, MeasureAmpResistorVal maResistorValue = MA_100K, int delayMS = 0, 
		const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false);

	/**
	* Setup Interface to force voltage mode, force the voltage, delay, and measure the resistance.
	* @devicecomm 
	*
	* @param resistorValue Expected Resistance value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param forceVoltage Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredResistance in ohms.
	*/
	double ResistorTestStringValue(const std::string & resistorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag , double forceVoltage = 0.15, MeasureAmpResistorVal maResistorValue = MA_100K, int delayMS = 0, 
		const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false);


	/**
	* Using the expected value determine the force voltage and force resistor, Setup the Interface to force voltage mode, force the voltage, delay, and measure the resistance.

	if( value < 2 )
	{
		forceVoltage = .020;
		maResistorValue = MA_100;
	}
	else if( 2 < value && value <= 10 )
	{
		forceVoltage = .150;
		maResistorValue = MA_100;
	}
	else if( 10 < value && value <= 20 )
	{
		forceVoltage = .300;
		maResistorValue = MA_100;
	}
	else if( 20 < value && value <= 100 )
	{
		forceVoltage = .150;
		maResistorValue = MA_1K;
	}
	else if( 100 < value && value <= 200 )
	{
		forceVoltage = .300;
		maResistorValue = MA_1K;
	}
	else if( 200 < value && value <= 1000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_10K;
	}
	else if( 1000 < value && value <= 2000 )
	{
		forceVoltage = .300;
		maResistorValue = MA_10K;
	}
	else if( 2000 < value && value <= 10000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_100K;
	}
	else if( 10000 < value && value <= 20000 )
	{
		forceVoltage = .300;
		maResistorValue = MA_100K;
	}
	else if( 20000 < value && value <= 100000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_1M;
	}
	else if( 100000 < value && value <= 200000 )
	{
		forceVoltage = .300;
		maResistorValue = MA_1M;
	}
	else if( 200000 < value && value <= 1000000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_10M;
	}
	else if( 1000000 < value )
	{
		forceVoltage = .300;
		maResistorValue = MA_10M;
	}

	* @devicecomm 
	*
	* @param resistorValue Expected Resistance value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredResistance in ohms.
	*/
	double ResistorTestAuto(double resistorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag, int delayMS = 0,
		const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false);

	/**
	* Using the expected value determine the force voltage and force resistor, Setup the Interface to force voltage mode, force the voltage, delay, and measure the resistance.

	if( value < 2 )
	{
		forceVoltage = .020;
		maResistorValue = MA_100;
	}
	else if( 2 < value && value <= 10 )
	{
		forceVoltage = .150;
		maResistorValue = MA_100;
	}
	else if( 10 < value && value <= 20 )
	{
		forceVoltage = .300;
		maResistorValue = MA_100;
	}
	else if( 20 < value && value <= 100 )
	{
		forceVoltage = .150;
		maResistorValue = MA_1K;
	}
	else if( 100 < value && value <= 200 )
	{
		forceVoltage = .300;
		maResistorValue = MA_1K;
	}
	else if( 200 < value && value <= 1000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_10K;
	}
	else if( 1000 < value && value <= 2000 )
	{
		forceVoltage = .300;
		maResistorValue = MA_10K;
	}
	else if( 2000 < value && value <= 10000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_100K;
	}
	else if( 10000 < value && value <= 20000 )
	{
		forceVoltage = .300;
		maResistorValue = MA_100K;
	}
	else if( 20000 < value && value <= 100000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_1M;
	}
	else if( 100000 < value && value <= 200000 )
	{
		forceVoltage = .300;
		maResistorValue = MA_1M;
	}
	else if( 200000 < value && value <= 1000000 )
	{
		forceVoltage = .150;
		maResistorValue = MA_10M;
	}
	else if( 1000000 < value )
	{
		forceVoltage = .300;
		maResistorValue = MA_10M;
	}

	* @devicecomm 
	*
	* @param resistorValue Expected Resistance value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredResistance in ohms.
	*/
	double ResistorTestAutoString(const std::string &resistorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag, int delayMS = 0,
		const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false);

	/**
	* Setup Interface to force voltage mode, force AC voltage, delay, and measure the absolute value of impedance, phase, resistance, and reactiance values.
	* @devicecomm
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param absImpedance The absolute value of the measured impedance
	* @param phase The measured phase angle of the impedance
	* @param resistance The measured resistance value
	* @param reactance The measured reactaince value
	* @param frequency Frequency for AC Force Voltage
	* @param vPeaktoPeak Peak to Peak Voltage for AC Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param dcOffset DC Offset for AC Force Voltage
	* @param MSPairMeasureRange Node A/B Voltage Range
	* @param MACurrentMeasureRange Measurement Amp Current Range
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	*/
	void ImpedanceTestAllParameters(const std::string &nodeA, const std::string &nodeB, const std::string &tag, double &absImpedance, double &phase, double &resistance, double &reactance, 
		double frequency = 1000, double vPeaktoPeak = 0.6, MeasureAmpResistorVal maResistorValue = MA_10K, double dcOffset = 0, double MSPairMeasureRange = 0.05, double MACurrentMeasureRange = 0.000005, 
		int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);

	/**
	* Setup Interface to force voltage mode, force AC voltage, delay, and measure the impedance. When measuring a resistor in series/parallel with a capacitor, choose the frequency that makes the capacitive reactance equal to the resistor value.
	* @devicecomm
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param absImpedance The absolute value of the measured impedance
	* @param phase The measured phase angle of the impedance
	* @param resistance The measured resistance value
	* @param reactance The measured reactaince value
	* @param frequency Frequency for AC Force Voltage
	* @param vPeaktoPeak Peak to Peak Voltage for AC Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param dcOffset DC Offset for AC Force Voltage
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	*/
	void ImpedanceTestValue(const std::string &nodeA, const std::string &nodeB, const std::string &tag, double &absImpedance, double &phase, double &resistance, double &reactance, double capacitorValue = 0.0 , double inductorValue = 0.0, double resistorValue = 0.0,
		double frequency = 1000, double vPeaktoPeak = 0.6, MeasureAmpResistorVal maResistorValue = MA_10K, double dcOffset = 0, int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);
	
	
	/**
	* Setup Interface to force voltage mode, force AC voltage, delay, and measure the impedance. When measuring a resistor in series/parallel with a capacitor, choose the frequency that makes the capacitive reactance equal to the resistor value.
	* @devicecomm
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param absImpedance The absolute value of the measured impedance
	* @param phase The measured phase angle of the impedance
	* @param resistance The measured resistance value
	* @param reactance The measured reactaince value
	* @param frequency Frequency for AC Force Voltage
	* @param vPeaktoPeak Peak to Peak Voltage for AC Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param dcOffset DC Offset for AC Force Voltage
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	*/
	void ImpedanceTestStringValue( const std::string &nodeA, const std::string &nodeB, const std::string &tag, double &absImpedance, double &phase, double &resistance, double &reactiance,
		const std::string & capacitorValue = "0.0",  const std::string & inductorValue = "0.0",  const std::string & resistorValue = "0.0",
		double frequency = 1000, double vPeaktoPeak = 0.6, MeasureAmpResistorVal maResistorValue = MA_10K, double dcOffset = 0, int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);
	/**
	* Setup Interface to force voltage mode, force AC voltage, delay, and measure the capacitance with Parallel Resistance.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param frequency Frequency for AC Force Voltage
	* @param vPeaktoPeak Peak to Peak Voltage for AC Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param dcOffset DC Offset for AC Force Voltage
	* @param MSPairMeasureRange Node A/B Voltage Range
	* @param MACurrentMeasureRange Measurement Amp Current Range
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCapacitance in farads.
	*/
	double CapacitorTestAllParameters(const std::string &nodeA, const std::string &nodeB, const std::string &tag, double frequency = 1000, double vPeaktoPeak = 0.4, MeasureAmpResistorVal maResistorValue = MA_10K,
		double dcOffset = 0, double MSPairMeasureRange = 0.05, double MACurrentMeasureRange = 0.000005, int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);
	/**
	* Setup Interface to force voltage mode, force AC voltage, delay, and measure the measure the absolute value of impedance, phase, resistance, and reactiance values.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param frequency Frequency for AC Force Voltage
	* @param vPeaktoPeak Peak to Peak Voltage for AC Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param dcOffset DC Offset for AC Force Voltage
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCapacitance in farads.
	*/
	double CapacitorTest(const std::string &nodeA, const std::string &nodeB, const std::string &tag, double frequency = 1000, double vPeaktoPeak = 0.4, MeasureAmpResistorVal maResistorValue = MA_10K,
		double dcOffset = 0, int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", bool saveWaveForm = false);

	/**
	* Setup Interface to force voltage mode, force AC voltage, delay, and measure the capacitance with resistance in Series.
	* @devicecomm 
	*
	* @param capacitorValue Expected Capacitor value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param frequency Frequency for AC Force Voltage
	* @param vPeaktoPeak Peak to Peak Voltage for AC Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param dcOffset DC Offset for AC Force Voltage
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCapacitance in farads.
	*/
	double CapacitorTestValue(double capacitorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag, double frequency = 1000, double vPeaktoPeak = 0.4, MeasureAmpResistorVal maResistorValue = MA_10K,
		double dcOffset = 0, int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);

	/**
	* Setup Interface to force voltage mode, force AC voltage, delay, and measure the capacitance with resistance in Series.
	* @devicecomm 
	*
	* @param capacitorValue Expected Capacitor value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param frequency Frequency for AC Force Voltage
	* @param vPeaktoPeak Peak to Peak Voltage for AC Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param dcOffset DC Offset for AC Force Voltage
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCapacitance in farads.
	*/
	double CapacitorTestStringValue(const std::string &capacitorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag, double frequency = 1000, double vPeaktoPeak = 0.4, MeasureAmpResistorVal maResistorValue = MA_10K,
		double dcOffset = 0, int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);

	/**
	* Using the expected value determine the frequency, AC voltage, then Setup Interface to force voltage AC mode, force AC voltage, delay, and measure the capacitance.

	//The Force Voltage divided by Expected Resistor value will get the Expected Measurement Current.(V=IR)
	
	//The Expected Measurement Current is multiple by Expected Resistor value to get Voltage across the Resistor.
	//This is Multiply by 2x for Voltage Range on the DMM (AiP16).
	//Expected Current is multiple by 2x to get Measurement Amp (AiP0) Current Range

	if (value >= 470e-6)
	{
		sineWaveFrequency = 15;
		maResistorValue = MA_10;
	}
	else if (value < 470e-6  && value >= 100e-6)
	{
		sineWaveFrequency = 30;
		maResistorValue = MA_10;
	}
	else if (value < 100e-6 && value >= 10e-6)
	{
		sineWaveFrequency = 100;
		maResistorValue = MA_100;
	}
	else if (value < 10e-6 && value >= 1e-6)
	{
		sineWaveFrequency = 1000;
		maResistorValue = MA_1K;
	}
	else if (value < 1e-6 && value >= 0.01e-6)
	{
		sineWaveFrequency = 1000;
		maResistorValue = MA_10K;
	}
	else if (value < 0.01e-6)
	{
		sineWaveFrequency = 10000;
		maResistorValue = MA_1M;
	}

	* @devicecomm 
	*
	* @param capacitorValue Expected Capacitor value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCapacitance in farads.
	*/
	double CapacitorTestAuto(double capacitorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag, int delayMS = 0,
		const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);

		/**
	* Using the expected value determine the frequency, AC voltage, then Setup Interface to force voltage AC mode, force AC voltage, delay, and measure the capacitance.

	//The Force Voltage divided by Expected Resistor value will get the Expected Measurement Current.(V=IR)
	
	//The Expected Measurement Current is multiple by Expected Resistor value to get Voltage across the Resistor.
	//This is Multiply by 2x for Voltage Range on the DMM (AiP16).
	//Expected Current is multiple by 2x to get Measurement Amp (AiP0) Current Range

	if (value >= 470e-6)
	{
		sineWaveFrequency = 15;
		maResistorValue = MA_10;
	}
	else if (value < 470e-6  && value >= 100e-6)
	{
		sineWaveFrequency = 30;
		maResistorValue = MA_10;
	}
	else if (value < 100e-6 && value >= 10e-6)
	{
		sineWaveFrequency = 100;
		maResistorValue = MA_100;
	}
	else if (value < 10e-6 && value >= 1e-6)
	{
		sineWaveFrequency = 1000;
		maResistorValue = MA_1K;
	}
	else if (value < 1e-6 && value >= 0.01e-6)
	{
		sineWaveFrequency = 1000;
		maResistorValue = MA_10K;
	}
	else if (value < 0.01e-6)
	{
		sineWaveFrequency = 10000;
		maResistorValue = MA_1M;
	}

	* @devicecomm 
	*
	* @param capacitorValue Expected Capacitor value
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param testMode Test In Series or Parrallel Reactance Mode
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCapacitance in farads.
	*/
	double CapacitorTestAutoString(const std::string &capacitorValue, const std::string &nodeA, const std::string &nodeB, const std::string &tag, int delayMS = 0,
		const std::string &nodeAP = "", const std::string &nodeBP = "", CapacitanceTestMode testMode = SERIESMEASUREMENT, bool saveWaveForm = false);

	/**
	* Setup Interface to force current mode, force the current, delay, and measure the voltage.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param forceCurrent Force Current
	* @param maResistorValue Force Resistor Value
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredVoltage in volts.
	*/
	double DiodeTest( const std::string &nodeA, const std::string &nodeB, const std::string &tag , double forceCurrent = 0.002, MeasureAmpResistorVal maResistorValue = MA_1K,
		int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", bool saveWaveForm = false);
	
	/**
	* Setup Interface to force voltage mode, force 0.3 volts, delay, and measure the current.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param currentLimit Max Current
	* @param maResistorValue Force Resistor Value
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCurrent in amps.
	*/
	double ShortTest( const std::string &nodeA, const std::string &nodeB, const std::string &tag , double currentLimit = 0.01, MeasureAmpResistorVal maResistorValue = MA_1K,
		int delayMS = 0, const std::string &nodeAP = "", const std::string &nodeBP = "", bool saveWaveForm = false);
	/**
	* Setup Interface to extended range force current mode, force the current, delay, and measure voltage.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param forceCurrent Force Current
	* @param range Max Voltage Range
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredVoltage in volts.
	*/
	double ZenerTest(  const std::string &nodeA, const std::string &nodeB, const std::string &tag , double forceCurrent = 0.005, double range = 0.0, int delayMS = 0,
		const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false );

	/**
	* Setup Interface to force voltage mode, force the voltage, delay, and measure the current.
	* @devicecomm 
	*
	* @param nodeA Source Node
	* @param nodeB Measurement Node
	* @param tag Component Name
	* @param forceVoltage Force Voltage
	* @param maResistorValue Force Resistor Value
	* @param delayMS Measurement Delay
	* @param nodeAP Guard Node 1
	* @param nodeBP Guard Node 2
	* @param fourWire Do Four Wire Test
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	* @return measuredCurrent in amps.
	*/
	double DepopResistorTest(const std::string &nodeA, const std::string &nodeB, const std::string &tag , double forceVoltage = 0.15, MeasureAmpResistorVal maResistorValue = MA_100K, int delayMS = 0, 
		const std::string &nodeAP = "", const std::string &nodeBP = "", bool fourWire = false, bool saveWaveForm = false);

	/**
	* Test Setup for a Digital Transistor.
	* @devicecomm 
	*
	* @param nodeA Base Node
	* @param nodeB Collector Node
	* @param nodeC Emitter Node
	* @param tag Component Name
	* @param baseCurrent Base Current
	* @param collectorCurrent Collector Current
	* @param collectorEmitterVoltage Collector Emitter Voltage
	* @param beta Transistor Beta
	* @param baseCurrentLimit Max Base Current
	* @param baseVoltage Force Base Voltage
	* @param collectorVoltage Force Collector Voltage
	* @param delayMS Measurement Delay
	* @param saveWaveForm Save Measurement Waveform to C:/Tester/DebugTraces
	*/
	void DigitalTransistorTest( const std::string &nodeA, const std::string &nodeB, const std::string &nodeC, const std::string &tag , double &baseCurrent, double &collectorCurrent, double &collectorEmitterVoltage, double &beta,
		double baseCurrentLimit = 0.010, double baseVoltage = 5.0, double collectorVoltage = 0.6, int delayMS = 100, bool saveWaveForm = false);

protected:
	boost::shared_ptr< C2ictIMP > m_imp;

private:
	C2ict( const C2ict& );
	C2ict& operator = ( const C2ict& );
};

#endif