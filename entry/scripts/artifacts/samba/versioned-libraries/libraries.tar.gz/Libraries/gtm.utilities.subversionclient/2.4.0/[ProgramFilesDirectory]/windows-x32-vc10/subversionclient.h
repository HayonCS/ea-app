/*
	@file
	@author randy.vandermate@getnex.com
	@author joshua.lareau@gentex.com
	@date 10/21/2014
	@brief Library wrapper for SVN Client functionality.
*/

#ifndef SUBVERSIONCLIENT_H
#define SUBVERSIONCLIENT_H

#include <string>

/**
 * @devicecomm
 * DO NOT EDIT - This property value will be updated automatically every time this file is committed to Subversion.
 * @NOTE The SVN keyword "header" property is required to be added to this file in order for this to work.
 */
static const char* __svninfo__ = "$Header: http://vcs.gentex.com/svn/testers/architecture/testplanutils/subversion/tags/2.4.x/include/subversionclient.h 257271 2016-09-23 16:35:06Z joshua.lareau $";

/**
 * @devicecomm 
 */
static const char* __documentation__ = "http://svnbook.red-bean.com/en/1.7/index.html";

/**
 * @devicecomm 
 */
static const char* __symbolicname__ = "gtm.utilities.subversionclient";

/**
	Subversion client utility library for use with DCIGen and the Test Plan Editor.
	This library only exposes SVN read operations. You cannot commit, delete, revert, add, etc...
	@devicecomm
*/
class SVNUtils
{
public:
	
	/*
		Does a fully recursive checkout of the specified SVN path and creates a working copy on disk.
		@devicecomm
		@param svnPath The subversion URL to checkout.
		@param localPath The location on disk to perform the checkout.
		@param revision The SVN revision of the path. Defaults to -1 for HEAD.
		@param ignoreExternals If true, externals will not be downloaded as part of the checkout. Defaults to false.
	*/
	static void Checkout( const std::string & svnPath, const std::string & localPath, const int revision = -1, bool ignoreExternals = false );
  
	/**
		Updates a working copy.
		@devicecomm
		@param localPath The location on disk where files have been checked out of SVN.
		@param revision The SVN revision to update to. Defaults to -1 for HEAD.
		@param ignoreExternals If true, externals will not be updated. Defaults to false.
	*/
	static void Update( const std::string & localPath, const int revision = -1, bool ignoreExternals = false );

	/**
		Exports the contents of a subversion repository into a clean directory (meaning a directory with no administrative SVN directories).
		@devicecomm
		@param svnPath The subversion URL to export the files from.
		@param localPath The location on disk to place the exported files.
		@param revision The SVN revision of the path. Defaults to -1 for HEAD.
		@param overwrite If true, any existing files in localPath will be overwritten. Defaults to false.
		@param ignoreExternals If true, externals will not be exported. Defaults to false.
	*/
	static void Export( const std::string & svnPath, const std::string & localPath, const int revision = -1, bool overwrite = false, bool ignoreExternals = false );


	/**
		Exports the contents of a subversion repository into a clean directory (meaning a directory with no administrative SVN directories).
		@devicecomm
		@param svnPath The subversion URL to export the files from.
		@param localPath The location on disk to place the exported files.
		@param revision The SVN revision of the path. Defaults to -1 for HEAD.
		@param overwrite If true, any existing files in localPath will be overwritten. Defaults to false.
		@param ignoreExternals If true, externals will not be exported. Defaults to false.
		@param recursive If true, all files and sub folders will be exported. Defaults to true.
	*/
	static void ExportRecursiveOption( const std::string & svnPath, const std::string & localPath, const int revision = -1, bool overwrite = false, bool ignoreExternals = false, bool recursive = true );

	/**
		Retrieves the contents of a single file from SVN and stores it in a string.
		@devicecomm
		@param svnPath The subversion URL of the file.
		@param revision The SVN revision of the file. Defaults to -1 for HEAD.
		@return fileContents The contents of the file.
	*/
	static std::string Cat( const std::string & svnPath, const int revision = -1 );

	/**
		Retrieves the contents of a single file from SVN and stores it on disk.
		@devicecomm
		@param svnPath The subversion URL of the file.
		@param destPath Filename in which the contents of the file file will be saved.
		@param revision The SVN revision of the file. Defaults to -1 for HEAD.
	*/
	static void Get( const std::string & svnPath, const std::string & destPath, const int revision = -1 );

	/**
		Recursively cleans up a local directory, finishing any incomplete operations, removing lock-files, etc...
		@devicecomm
		@param localPath The location on disk to cleanup.
	*/
	static void Cleanup( const std::string & localPath );

};
#endif // SUBVERSIONCLIENT_H
